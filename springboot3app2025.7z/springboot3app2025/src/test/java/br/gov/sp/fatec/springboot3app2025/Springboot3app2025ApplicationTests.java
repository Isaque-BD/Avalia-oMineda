package br.gov.sp.fatec.springboot3app2025;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot3app2025ApplicationTests {

	@Test
	void contextLoads() {
	}

}
