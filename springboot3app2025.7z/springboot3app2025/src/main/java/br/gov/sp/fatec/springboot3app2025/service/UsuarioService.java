package br.gov.sp.fatec.springboot3app2025.service;

import java.util.List;

import org.springframework.stereotype.Service;

import br.gov.sp.fatec.springboot3app2025.entity.Usuario;
import br.gov.sp.fatec.springboot3app2025.repository.UsuarioRepository;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    public UsuarioService(UsuarioRepository usuarioRepository){
        this.usuarioRepository = usuarioRepository;
    }

    public List<Usuario> procurarTituloNota(String titulo, int nota){
        return usuarioRepository.encontrarNotaETitulo(titulo, nota);
    }
    
}
