package br.gov.sp.fatec.springboot3app2025;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot3app2025Application {

	public static void main(String[] args) {
		SpringApplication.run(Springboot3app2025Application.class, args);
	}

}
