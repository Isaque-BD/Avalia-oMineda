package br.gov.sp.fatec.springboot3app2025.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.gov.sp.fatec.springboot3app2025.entity.Usuario;
import br.gov.sp.fatec.springboot3app2025.service.UsuarioService;

@RestController
@RequestMapping("/teste")
public class UsuarioController {
    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService){
        this.usuarioService = usuarioService;
    }

    @GetMapping("/filter")
    public List<Usuario> filtroTituloNota(
        @RequestParam String titulo,
        @RequestParam int nota
    ){
        return usuarioService.procurarTituloNota(titulo, nota);
    }

    
}
