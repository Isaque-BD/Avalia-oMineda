package br.gov.sp.fatec.springboot3app2025.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.gov.sp.fatec.springboot3app2025.entity.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long>{

    @Query(
        value = "Select t FROM Usuario t WHERE t.tra_titulo like CONCAT('%', :tra_titulo, '%') AND t.tra_nota > :minima"
    )
    List<Usuario> encontrarNotaETitulo(
        @Param("tra_nota") String tranota,
        @Param("minima") int minima
    );
    
}
